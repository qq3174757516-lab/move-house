<template>
  <div class='container'>
    <van-swipe :autoplay='2000' :show-indicators='false'>
      <van-swipe-item v-for='(tip, idx) in tipList' :key='tip.id'>
        <div class='tip-item' @click='onTip(idx)'>
          <van-icon name='info-o' />
          <span>{{ tip.title }}</span>
        </div>
      </van-swipe-item>
    </van-swipe>

    <div class='publish-list' v-if='publishList.length > 0'>
      <div v-for='item in publishList' :key='item.id' class='publish-item' @click='$router.push(`/publish/${item.id}`)'>
        <div class='publish-tip'>
          <span>发布者: {{ item.username }}</span>
          <span>{{ item.title }}</span>
          <span>{{ item.createTime }}</span>
        </div>
        <div class='publish-content'>
          <van-image :src='$baseUrl + item.cover' width='100px' />
          <p>{{ item.content }}</p>
        </div>
        <p>地址: {{ item.address }}</p>
        <p class='price'>价格: {{ item.valuation ? '¥' + item.valuation.toFixed(2) : '未出价'
          }}</p>
        <div @click.stop class='publish-btns' v-if='user.userType === 3'>
          <van-button size='mini' type='info' v-if='item.status === 0' @click='onEdit(item)'>
            修改
          </van-button>
          <van-button size='mini' type='danger' v-if='item.status === 0' @click='onDelete(item.id)'>
            取消发布
          </van-button>
          <van-button size='mini' type='primary' v-if='item.status === 1' @click='onProcess(item.id, 1)'>
            同意
          </van-button>
          <van-button size='mini' type='danger' v-if='item.status === 1' @click='onProcess(item.id, 0)'>
            拒绝
          </van-button>
          <van-button size='mini' type='primary' v-if='item.status === 2'>
            已完成
          </van-button>
        </div>
        <div class='publish-btns' @click.stop v-if='user.userType === 2'>
          <!--          <van-button size='mini' type='info' v-if='item.status === 0' @click='onValuation(item.id)'>
                      接单
                    </van-button>-->

          <van-button size='mini' type='info' v-if='item.status === 0' @click='$router.push(`/publish/${item.id}`)'>
            查看详情
          </van-button>

          <van-button size='mini' type='primary' v-if='item.status === 1'>
            已接单
          </van-button>
        </div>
      </div>
    </div>
    <van-empty v-else>还没有搬家发布信息</van-empty>

    <FloatBtn v-if='user.userType === 3' @click.native='onAdd' text='发布搬家信息' icon='plus' :show='floatShow' />

    <van-popup v-model='popupShow' position='bottom' @close='floatShow = true'>
      <div class='form'>
        <span class='form-title'>填写搬家信息</span>
        <van-form ref='formRef' @submit='submit' label-width='60px'>
          <van-field
            v-model='form.title'
            label='标题'
            placeholder='标题'
            :rules="[{ required: true, message: '请填写标题' }]"
          />
          <van-field
            v-model='form.content'
            type='textarea'
            label='内容'
            placeholder='内容'
            :rules="[{ required: true, message: '请填写内容' }]"
          />
          <van-field
            v-model='form.address'
            type='textarea'
            label='地址'
            placeholder='地址'
            :rules="[{ required: true, message: '请填写地址' }]"
          />
          <van-field label='封面'>
            <template #input>
              <van-uploader
                v-model='covers'
                :max-count='1'
                :before-read='beforeRead'
                :after-read='afterReadCover'
              />
            </template>
          </van-field>
          <van-field label='物品图片'>
            <template #input>
              <van-uploader
                v-model='form.imgArr'
                :max-count='5'
                :before-read='beforeRead'
                :after-read='afterReadImgs'
              />
            </template>
          </van-field>
          <div style='margin: 16px'>
            <van-button round block type='info' native-type='submit'>提交</van-button>
          </div>
        </van-form>
      </div>
    </van-popup>

    <van-popup v-model='tipPopupShow' style='border-radius: 15px;overflow: hidden'>
      <div style='padding: 15px'>
        <div v-html='tipList[tipIndex]?.content' />
      </div>
    </van-popup>

    <van-popup v-model='valuationShow' style='border-radius: 15px;overflow: hidden'>
      <div style='padding: 15px'>
        <van-field
          label-width='50px'
          v-model='valuationForm.valuation'
          type='number'
          label='价格'
          placeholder='价格'
          :rules="[{ required: true, message: '请填写价格' }]"
        >
          <template #right-icon>
            <span>元</span>
          </template>
        </van-field>
        <van-button @click='valuationSubmit' size='small' type='info' round block>提交</van-button>
      </div>
    </van-popup>
  </div>
</template>

<script>
import {
  pagePublishApi,
  createPublishApi,
  deletePublishApi,
  updatePublishApi,
  valuationPublishApi,
  processPublishApi
} from '@/api/publish'
import { uploadApi } from '@/api/file'
import { listTipApi } from '@/api/tip'
import FloatBtn from '@/components/FloatBtn.vue'
import { mapState } from 'vuex'

export default {
  components: { FloatBtn },
  data() {
    return {
      floatShow: true,
      popupShow: false,
      valuationShow: false,
      publishList: [],
      tipList: [],
      tipIndex: 0,
      tipPopupShow: false,
      covers: [],
      query: {
        current: 1,
        size: 999,
        total: 0
      },
      form: {
        title: '',
        content: '',
        address: '',
        cover: '',
        imgs: '',
        imgArr: []
      },
      valuationForm: {
        id: 0,
        valuation: 0
      }
    }
  },
  methods: {
    onProcess(id, isAccept) {
      let message
      if (isAccept) {
        message = '是否接受此价格, 并结账?'
      } else {
        message = '是否拒绝此价格, 并重新发布?'
      }
      this.$dialog.confirm({
        title: '温馨提示',
        message
      }).then(async () => {
        await processPublishApi(id, isAccept)
        this.$toast.success('操作成功!')
        await this.pagePublish()
      }).catch(() => {
      })
    },
    async valuationSubmit() {
      if (this.valuationForm.valuation <= 0) {
        this.$toast('请填写价格!')
        return
      }
      await valuationPublishApi(this.valuationForm)
      this.$toast.success('操作成功!')
      this.valuationShow = false
      await this.pagePublish()
    },
    onValuation(id) {
      this.valuationForm.id = id
      this.valuationForm.valuation = 0
      this.valuationShow = true
    },
    onDelete(id) {
      this.$dialog.confirm({
        title: '温馨提示',
        message: '你确定要删除这个搬家信息吗?'
      }).then(async () => {
        await deletePublishApi(id)
        this.$toast.success('操作成功!')
        await this.pagePublish()
      }).catch(() => {
      })
    },
    async submit() {
      this.form.imgs = this.form.imgArr.map(item => item.img).join(',')
      this.form.cover = this.covers[0]?.img || ''
      if (this.form.id) {
        await updatePublishApi(this.form)
      } else {
        await createPublishApi(this.form)
      }
      this.$toast.success('操作成功!')
      await this.pagePublish()
      this.popupShow = false
    },
    async afterReadCover(file) {
      const { data: url } = await uploadApi(file.file)
      file.img = url
    },
    async afterReadImgs(file) {
      const { data: url } = await uploadApi(file.file)
      file.img = url
    },
    beforeRead(file) {
      if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
        this.$toast('请上传 jpg 或者 png 格式图片!')
        return false
      }
      return true
    },
    onTip(idx) {
      this.tipIndex = idx
      this.tipPopupShow = true
    },
    onEdit(item) {
      this.popupShow = true
      this.floatShow = false
      this.form = { ...item, imgArr: [] }
      this.covers = [{ url: this.$baseUrl + item.cover, img: item.cover }]
      this.form.imgArr = item.imgs.split(',').map(img => ({ url: this.$baseUrl + img, img }))
    },
    onAdd() {
      this.popupShow = true
      this.floatShow = false
      this.form = {
        title: '',
        content: '',
        address: '',
        cover: '',
        imgs: '',
        imgArr: []
      }
      this.covers = []
    },
    async pagePublish() {
      const { data } = await pagePublishApi(this.query)
      this.publishList = data.rows
      this.query.total = data.total
    },
    async listTip() {
      const { data } = await listTipApi()
      this.tipList = data
    }
  },
  created() {
    this.pagePublish()
    this.listTip()
  },
  computed: {
    ...mapState(['user'])
  }
}
</script>

<style lang='scss' scoped>
.publish-list {
  height: 100%;
  margin: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 12px;
  overflow: auto;
  padding-bottom: 100px;

  .publish-item {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 10px;
    background: white;
    border-radius: 10px;
    margin-bottom: 15px;

    .publish-tip {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: gray;
    }

    .publish-content {
      width: 100%;
      display: flex;
      margin: 10px 0;

      .van-image {
        width: 100px;
        min-height: 60px;
      }

      p {
        flex: 1;
        margin-left: 10px;
        font-size: 15px;
      }
    }

    .price {
      font-size: 14px;
      font-weight: 700;
      color: #f39c12;
    }

    .publish-btns {
      width: 100%;
      display: flex;
      justify-content: flex-end;
    }

    p {
      width: 100%;
      text-align: left;
    }
  }
}

.van-swipe {
  width: 100%;
  height: 40px;
}

.tip-item {
  display: flex;
  width: 100%;
  height: 40px;
  justify-content: center;
  align-items: center;
  background-color: rgba(243, 156, 18, .1);
  color: #f39c12;

  .van-icon {
    margin-right: 5px;
    font-size: 18px;
  }
}

.form {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;

  .van-form {
    width: 100%;
  }

  .form-title {
    font-size: 18px;
    font-weight: 700;
    padding: 15px;
    color: #1989fa;
  }
}

.container {
  height: 100%;
}
</style>
