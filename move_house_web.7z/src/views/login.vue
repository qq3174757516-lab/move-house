<template>
  <div class='container'>
    <p class='title'>
      <span v-if='status === 0'>
        {{ userType === 1 ? 'USER LOGIN' : 'DRIVER LOGIN' }}
      </span>
      <span v-else>
        {{ userType === 1 ? 'USER REGISTER' : 'DRIVER REGISTER' }}
      </span>
    </p>
    <p />
    <van-form ref='formRef' @submit='submit'>
      <van-field
        v-model='form.username'
        label='用户名'
        placeholder='用户名/手机号'
        :rules="[{ required: true, message: '请填写用户名/手机号' }]"
      />
      <van-field
        v-if='status === 1'
        v-model='form.phone'
        label='手机号'
        placeholder='手机号'
        :rules="[{ required: true, message: '请填写手机号' }]"
      />
      <van-field
        v-if='status === 1 && userType === 1'
        v-model='form.nickname'
        label='昵称'
        placeholder='昵称'
        :rules="[{ required: true, message: '请填写昵称' }]"
      />
      <van-field
        v-if='status === 1 && userType === 2'
        v-model='form.name'
        label='姓名'
        placeholder='姓名'
        :rules="[{ required: true, message: '请填写姓名' }]"
      />
      <van-field
        v-if='status === 1 && userType === 2'
        v-model='form.idCard'
        label='身份证'
        placeholder='身份证'
        :rules="[{ required: true, message: '请填写身份证' }]"
      />
      <van-field
        v-if='status === 1 && userType === 2'
        v-model='form.carAge'
        type='digit'
        label='驾龄'
        placeholder='驾龄'
        :rules="[{ required: true, message: '请填写驾龄' }]"
      />
      <van-field
        v-model='form.password'
        type='password'
        label='密码'
        placeholder='密码'
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <van-field
        v-if='status === 1'
        v-model='form.confirmPass'
        type='password'
        label='确认密码'
        placeholder='确认密码'
        :rules="[{ required: true, message: '请填写确认密码' }]"
      />
      <div style='margin: 16px'>
        <van-button round block type='info' native-type='submit'>提交</van-button>
      </div>
    </van-form>

    <FloatBtn @click.native='changeUserType' :text='text' />

    <span v-show='status === 0' class='tip' @click='() => status = 1'>还没有账号? 马上注册</span>
    <span v-show='status === 1' class='tip' @click='() => status = 0'>已有账号? 立即登录</span>
  </div>
</template>

<script>
import { loginApi, registerApi } from '@/api/user'
import { loginDriverApi, registerDriverApi } from '@/api/driver'
import { mapActions } from 'vuex'
import FloatBtn from '@/components/FloatBtn.vue'

export default {
  components: { FloatBtn },
  data() {
    return {
      //0是登录, 1是注册
      status: 0,
      //1是用户, 2是司机注册
      userType: 1,
      text: '我是司机',
      form: {
        username: '',
        password: '',
        phone: '',
        confirmPass: '',
        nickname: '',
        idCard: '',
        name: '',
        carAge: ''
      }
    }
  },
  methods: {
    ...mapActions(['setUser', 'changeLogin']),
    changeUserType() {
      if (this.userType === 1) {
        this.userType = 2
        this.text = '我是用户'
      } else {
        this.userType = 1
        this.text = '我是司机'
      }
      this.$refs.formRef.resetValidation()
    },
    async submit() {
      if (this.status === 0) {
        let data
        if (this.userType === 1) {
          data = (await loginApi(this.form)).data
        } else {
          data = (await loginDriverApi(this.form)).data
        }
        this.$toast.success('登录成功')
        await this.setUser({ ...data })
        await this.changeLogin(true)
        await this.$router.replace('/')
        return
      }

      if (this.form.password !== this.form.confirmPass) {
        return this.$toast('密码不一致, 请确认!')
      }

      if (this.userType === 1) {
        await registerApi(this.form)
      } else {
        await registerDriverApi(this.form)
      }
      this.$toast.success('注册成功')
      this.status = 0
    }
  }
}
</script>

<style lang='scss' scoped>
.tip {
  position: absolute;
  bottom: 30px;
  color: lightgray;
  font-size: 12px;
  user-select: none;

  &:active {
    color: green;
  }
}

.title {
  color: lightgray;
  font-size: 30px;
  font-weight: 700;
  margin: 0;
}

.container {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
</style>
