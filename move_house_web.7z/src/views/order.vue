<template>
  <div class='container'>
    <div v-if='orderList.length > 0' class='order-list'>
      <div class='order-item' v-for='order in orderList' :key='order.id'>
        <div class='order-tip'>
          <span>订单号: {{ order.orderNo }}</span>
          <span>{{ order.createTime }}</span>
        </div>
        <div class='order-content'>
          <span>用户: {{ order.username }}</span>
          <span>司机: {{ order.driverName }}</span>
        </div>
        <p>地址: {{ order.address }}</p>
        <p class='price'>订单金额: ¥{{ order.price.toFixed(2) }}</p>
        <div class='order-btns' v-if='user.userType === 3'>
          <van-button v-if='order.status === 0' type='info' size='small' @click='onArrive(order.id)'>
            司机是否已到达
          </van-button>
          <van-button v-else-if='order.status === 1' type='primary' size='small' @click='onFinish(order.id)'>
            搬家是否完毕
          </van-button>
          <van-button v-else-if='!order.isComplaint' type='danger' size='small' @click='onComplaint(order)'>
            订单投诉
          </van-button>
          <van-button v-else type='danger' size='small'>订单已投诉</van-button>
        </div>

        <div class='order-btns' v-if='user.userType === 2'>
          <van-tag v-if='order.status === 0' type='primary'>待用户确认您已到达</van-tag>
          <van-tag v-else-if='order.status === 1' type='success'>待用户确认订单完成</van-tag>
          <van-tag v-else-if='!order.isComplaint' type='success'>订单已完成</van-tag>
          <van-tag v-else type='danger'>用户已投诉</van-tag>
        </div>
      </div>
    </div>

    <van-empty v-if='orderList.length === 0'>还没有订单</van-empty>

    <van-popup v-model='popupShow'>
      <div class='form'>
        <span class='form-title'>订单投诉</span>
        <van-form ref='formRef' @submit='submit' label-width='60px'>
          <van-field
            v-model='form.reason'
            type='textarea'
            label='投诉理由'
            placeholder='投诉理由'
            :rules="[{ required: true, message: '请填写投诉理由' }]"
          />
          <van-field label='详情图片'>
            <template #input>
              <van-uploader
                v-model='form.imgArr'
                :max-count='2'
                :before-read='beforeRead'
                :after-read='afterReadImgs'
              />
            </template>
          </van-field>
          <div style='margin: 16px'>
            <van-button round block type='danger' native-type='submit'>提交</van-button>
          </div>
        </van-form>
      </div>
    </van-popup>
  </div>
</template>

<script>
import { pageOrderApi, arriveOrderApi, finishOrderApi } from '@/api/order'
import { createComplaintApi } from '@/api/complaint'
import { uploadApi } from '@/api/file'
import { mapState } from 'vuex'

export default {
  data() {
    return {
      popupShow: false,
      orderList: [],
      query: {
        current: 1,
        size: 9999
      },
      form: {
        imgArr: []
      }
    }
  },
  methods: {
    onComplaint(order) {
      this.form.driverId = order.driverId
      this.form.driverName = order.driverName
      this.form.userId = order.userId
      this.form.username = order.username
      this.form.orderId = order.id
      this.popupShow = true
    },
    async submit() {
      this.form.imgs = this.form.imgArr.map(item => item.img).join(',')
      await createComplaintApi(this.form)
      this.$toast.success('投诉成功!')
      await this.listOrder()
      this.popupShow = false
    },
    async afterReadImgs(file) {
      const { data: url } = await uploadApi(file.file)
      file.img = url
    },
    beforeRead(file) {
      if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
        this.$toast('请上传 jpg 或者 png 格式图片!')
        return false
      }
      return true
    },
    async onArrive(id) {
      this.$dialog.confirm({
        title: '温馨提示',
        message: '你确认司机已经到达了吗?'
      }).then(async () => {
        await arriveOrderApi(id)
        await this.listOrder()
      }).catch(() => {
      })
    },
    async onFinish(id) {
      this.$dialog.confirm({
        title: '温馨提示',
        message: '你确认物品已经搬完了吗?'
      }).then(async () => {
        await finishOrderApi(id)
        await this.listOrder()
      }).catch(() => {
      })
    },
    async listOrder() {
      const { data } = await pageOrderApi(this.query)
      this.orderList = data.rows
    }
  },
  computed: {
    ...mapState(['user'])
  },
  mounted() {
    this.listOrder()
  }
}
</script>

<style lang='scss' scoped>
.form {
  width: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;

  .van-form {
    width: 100%;
  }

  .form-title {
    font-size: 18px;
    font-weight: 700;
    padding: 15px;
    color: red;
  }
}

.van-tag {
  padding: 5px;
}

.order-list {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 14px;
  overflow: auto;
  margin: 10px 0;

  .order-item {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    background-color: white;
    border-radius: 10px;
    margin-bottom: 15px;

    .order-tip, .order-content {
      display: flex;
      justify-content: space-between;
      width: 100%;
    }

    .order-content {
      font-size: 16px;
      color: #1989fa;
      margin: 10px 0;
    }

    .price {
      width: 100%;
      font-size: 16px;
      font-weight: 700;
      color: #f39c12;
      padding: 10px 0;
    }

    p {
      width: 100%;
    }

    .order-btns {
      width: 100%;
      display: flex;
      justify-content: flex-end;
    }
  }
}

.container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 15px;
}
</style>