<template>
  <div class='container'>
    <div class='top'>
      <el-button type='success' @click='onAdd'>创建通知</el-button>
    </div>
    <el-table border :data='tableData'>
      <el-table-column prop='id' label='编号' align='center' />
      <el-table-column prop='title' label='标题' align='center' />
      <el-table-column prop='content' label='内容' align='center' show-overflow-tooltip />
      <el-table-column prop='status' label='状态' align='center'>
        <template #default='scope'>
          <el-tag v-if='scope.row.status === 1'>正常</el-tag>
          <el-tag v-else type='danger'>已关闭</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop='createTime' label='发布时间' align='center' />
      <el-table-column fixed='right' label='操作' width='150' align='center'>
        <template #default='scope'>
          <el-button size='mini' style='margin-right: 10px' type='primary' @click='onEdit(scope.row)'>修改</el-button>
          <el-popconfirm title='确定删除这条通知吗' @confirm='onDelete(scope.row.id)'>
            <template #reference>
              <el-button size='mini' type='danger'>删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog center :close-on-click-modal='false' :title='title' :visible.sync='dialogVisible' width='600px'>
      <el-form ref='formRef' :model='form' :rules='rules' label-width='100px'>
        <el-form-item label='标题' prop='title'>
          <el-input placeholder='请填写标题' v-model='form.title' />
        </el-form-item>
        <el-form-item label='通知内容' prop='content'>
          <editor v-model='form.content' />
        </el-form-item>
        <el-form-item label='状态' prop='status'>
          <el-switch v-model='form.status' :inactive-value='0' :active-value='1' />
        </el-form-item>
      </el-form>
      <span slot='footer' class='dialog-footer'>
        <el-button @click='dialogVisible = false'>取 消</el-button>
        <el-button type='primary' @click='submit'>确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { createTipApi, deleteTipApi, updateTipApi, listTipApi } from '@/api/tip'
import Editor from '@/components/Editor.vue'

export default {
  components: { Editor },
  data: () => ({
    tableData: [],
    form: {
      title: '',
      content: '',
      status: 1
    },
    rules: {
      title: [{ required: true, message: '标题不能为空', trigger: 'blur' }],
      content: [{ required: true, message: '内容不能为空', trigger: 'blur' }],
      status: [{ required: true, message: '状态不能为空', trigger: 'blur' }]
    },
    title: '创建通知',
    dialogVisible: false
  }),
  methods: {
    submit() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return

        if (this.form.id) {
          await updateTipApi(this.form)
        } else {
          await createTipApi(this.form)
        }

        await this.listTip()
        this.dialogVisible = false
      })
    },
    async onDelete(id) {
      await deleteTipApi(id)
      await this.listTip()
    },
    onEdit(row) {
      this.title = '修改通知'
      this.form = { ...row }
      this.dialogVisible = true
    },
    onAdd() {
      this.title = '创建通知'
      this.form = {
        title: '',
        content: '',
        status: 1
      }
      this.dialogVisible = true
    },
    async listTip() {
      const { data } = await listTipApi()
      this.tableData = data
    }
  },
  mounted() {
    this.listTip()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;
}
</style>
