<template>
  <div class='container'>
    <div class='top'>
      <el-input v-model='query.keyword' placeholder='关键字搜索' clearable />
      <el-button type='primary' @click='pageUser'>搜索</el-button>
    </div>

    <el-table border :data='tableData' height='500'>
      <el-table-column prop='username' label='用户名' align='center' />
      <el-table-column prop='nickname' label='姓名' align='center' />
      <el-table-column prop='phone' label='号码' align='center' width='120' />
      <el-table-column prop='avatar' label='头像' align='center'>
        <template #default='scope'>
          <el-avatar :src='$baseUrl + scope.row.avatar' />
        </template>
      </el-table-column>
      <el-table-column prop='balance' label='余额' align='center' />
      <el-table-column prop='createTime' label='注册时间' align='center' width='150' />
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[6, 10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />
  </div>
</template>

<script>
import { pageUserApi } from '@/api/user'

export default {
  data: () => ({
    tableData: [],
    query: {
      current: 1,
      size: 6,
      total: 0,
      keyword: ''
    }
  }),
  methods: {
    handleCurrentChange(val) {
      this.query.current = val
      this.pageUser()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pageUser()
    },
    async pageUser() {
      const { data } = await pageUserApi(this.query)
      this.tableData = data.rows
      this.query.total = data.total
    }
  },
  mounted() {
    this.pageUser()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-input {
    width: 150px;
    margin-right: 15px;
  }
}
</style>
