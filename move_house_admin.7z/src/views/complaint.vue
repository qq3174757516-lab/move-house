<template>
  <div class='container'>
    <div class='top'>
      <el-select v-model='query.driverId' clearable placeholder='选择司机'>
        <el-option v-for='d in driverList' :key='d.id' :value='d.id' :label='d.name' />
      </el-select>
      <el-button type='primary' @click='pageComplaint'>搜索</el-button>
    </div>

    <el-table border :data='tableData' height='500'>
      <el-table-column prop='id' label='投诉编号' align='center' width='100' />
      <el-table-column prop='driverName' label='司机名称' align='center' />
      <el-table-column prop='username' label='用户名' align='center' />
      <el-table-column prop='reason' label='投诉理由' align='center' show-overflow-tooltip />
      <el-table-column prop='imgs' label='投诉图片资料' align='center'>
        <template #default='scope'>
          <el-image :src='scope.row.imgArr[0]' :preview-src-list='scope.row.imgArr' />
        </template>
      </el-table-column>
      <el-table-column prop='createTime' label='投诉时间' align='center' width='150' />
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[6, 10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />
  </div>
</template>

<script>
import { pageComplaintApi } from '@/api/complaint'
import { listDriverApi } from '@/api/driver'

export default {
  data: () => ({
    tableData: [],
    driverList: [],
    query: {
      current: 1,
      size: 6,
      total: 0,
      driverId: null
    }
  }),
  methods: {
    handleCurrentChange(val) {
      this.query.current = val
      this.pageComplaint()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pageComplaint()
    },
    async pageComplaint() {
      const { data } = await pageComplaintApi(this.query)
      data.rows.forEach(item => {
        item.imgArr = item.imgs.split(',').map(img => this.$baseUrl + img)
      })
      this.tableData = data.rows
      this.query.total = data.total
    },
    async listDriver() {
      const { data } = await listDriverApi()
      this.driverList = data
    }
  },
  mounted() {
    this.pageComplaint()
    this.listDriver()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-select {
    width: 150px;
    margin-right: 15px;
  }
}
</style>
