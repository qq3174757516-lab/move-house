<template>
  <div class='box'>
    <span class='title'>LOGIN</span>
    <el-form ref='loginFormRef' :model='form' :rules='rules'>
      <el-form-item prop='username'>
        <el-input autocomplete='off' v-model='form.username' placeholder='用户名' clearable />
      </el-form-item>
      <el-form-item prop='password'>
        <el-input autocomplete='off' show-password type='password' v-model='form.password' placeholder='密码'
                  @keydown.enter.native='submit' />
      </el-form-item>
    </el-form>
    <el-button class='btn-submit' type='primary' @click='submit'>提交</el-button>
  </div>
</template>

<script>
import { loginAdminApi } from '@/api/admin'
import { mapActions } from 'vuex'

export default {
  data() {
    return {
      form: {
        username: '',
        password: ''
      },
      rules: {
        username: [{ required: true, message: '用户名不能为空', trigger: 'blur' }],
        password: [{ required: true, message: '密码不能为空', trigger: 'blur' }]
      }
    }
  },
  methods: {
    ...mapActions(['setUser']),
    submit() {
      this.$refs.loginFormRef.validate(async valid => {
        if (!valid) return
        const { data } = await loginAdminApi(this.form)
        data.avatar = 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
        await this.setUser(data)
        await this.$router.push('/')
      })
    }
  }
}
</script>

<style lang='scss' scoped>
$form-width: 300px;

.btn-submit {
  width: $form-width;
}

.el-form {
  width: $form-width;
}

.title {
  font-size: 30px;
  font-weight: 800;
  color: lightgray;
  user-select: none;
  margin-bottom: 20px;
}

.box {
  width: 400px;
  position: absolute;
  top: 50%;
  left: 50%;
  padding: 20px;
  transform: translate(-50%, -50%);
  border-radius: 15px;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0 0 30px rgba(0, 0, 0, .1);
}
</style>
