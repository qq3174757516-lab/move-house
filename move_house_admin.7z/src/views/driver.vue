<template>
  <div class='container'>
    <div class='top'>
      <el-input v-model='query.keyword' placeholder='关键字搜索' clearable />
      <el-select v-model='query.gender' placeholder='性别' clearable>
        <el-option :value='0' label='男' />
        <el-option :value='1' label='女' />
      </el-select>
      <el-select v-model='query.status' placeholder='状态' clearable>
        <el-option :value='0' label='待审核' />
        <el-option :value='1' label='正常' />
        <el-option :value='2' label='已解雇' />
      </el-select>
      <el-button type='primary' @click='pageDriver'>搜索</el-button>
    </div>

    <el-table v-loading='loading' border :data='tableData' height='500'>
      <el-table-column prop='username' label='用户名' align='center' />
      <el-table-column prop='name' label='姓名' align='center' />
      <el-table-column prop='phone' label='号码' align='center' width='120' />
      <el-table-column prop='avatar' label='头像' align='center'>
        <template #default='scope'>
          <el-avatar :src='$baseUrl + scope.row.avatar' />
        </template>
      </el-table-column>
      <el-table-column prop='idCard' label='身份证' align='center' width='150' />
      <el-table-column prop='age' label='年龄' align='center' />
      <el-table-column prop='carAge' label='驾龄' align='center' />
      <el-table-column prop='car.name' label='车辆' align='center' width='100' />
      <el-table-column prop='car.carNo' label='车牌号' align='center' width='100' />
      <el-table-column prop='gender' label='性别' align='center'>
        <template #default='scope'>
          <el-tag v-if='scope.row.gender === 0'>男</el-tag>
          <el-tag v-else type='danger'>女</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop='income' label='收入' align='center' />
      <el-table-column prop='complaintNum' label='投诉数量' align='center' />
      <el-table-column prop='status' label='状态' align='center'>
        <template #default='scope'>
          <el-tag v-if='scope.row.status === 0' type='info'>待审核</el-tag>
          <el-tag v-else-if='scope.row.status === 1'>正常</el-tag>
          <el-tag v-else type='danger'>已解雇</el-tag>
        </template>
      </el-table-column>
      <el-table-column fixed='right' label='操作' width='150' align='center'>
        <template #default='scope'>
          <el-button v-show='scope.row.status === 0' size='mini' type='primary' @click='onAccept(scope.row.id)'>通过</el-button>
          <el-popconfirm v-show='scope.row.status === 1' title='确定解雇该司机吗?' @confirm='onDismiss(scope.row.id)'>
            <template #reference>
              <el-button size='mini' type='danger'>解雇</el-button>
            </template>
          </el-popconfirm>
          <el-popconfirm v-show='scope.row.status === 2' title='确定删除该司机吗?' @confirm='onDelete(scope.row.id)'>
            <template #reference>
              <el-button size='mini' type='danger'>删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[6, 10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />

    <el-dialog center :close-on-click-modal='false' title='分配车辆' :visible.sync='dialogVisible' width='400px'>
      <el-form ref='formRef' :model='form' :rules='rules' label-width='100px'>
        <el-form-item label='车辆' prop='carId'>
          <el-select v-model='form.carId'>
            <el-option v-for='c in carList' :key='c.id' :value='c.id' :label='`${c.name}-${c.carNo}`' />
          </el-select>
        </el-form-item>
      </el-form>
      <span slot='footer' class='dialog-footer'>
        <el-button @click='dialogVisible = false'>取 消</el-button>
        <el-button type='primary' @click='submit'>确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { pageDriverApi, acceptDriverApi, dismissDriverApi, deleteDriverApi } from '@/api/driver'
import { listCarApi } from '@/api/car'

export default {
  data: () => ({
    loading: false,
    tableData: [],
    carList: [],
    query: {
      current: 1,
      size: 6,
      total: 0,
      keyword: '',
      gender: null,
      status: null
    },
    form: {
      id: null,
      carId: null
    },
    dialogVisible: false,
    rules: {
      carId: [{ required: true, message: '分配车辆不能为空', trigger: 'blur' }]
    }
  }),
  methods: {
    submit() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        await acceptDriverApi(this.form.id, this.form.carId)
        await this.listCar()
        await this.pageDriver()
        this.dialogVisible = false
      })
    },
    async onDelete(id) {
      await deleteDriverApi(id)
      await this.pageDriver()
    },
    onAccept(id) {
      this.form.id = id
      this.form.carId = this.carList[0].id
      this.dialogVisible = true
    },
    async onDismiss(id) {
      await dismissDriverApi(id)
      await this.pageDriver()
    },
    handleCurrentChange(val) {
      this.query.current = val
      this.pageDriver()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pageDriver()
    },
    async pageDriver() {
      this.loading = true
      const { data } = await pageDriverApi(this.query)
      this.tableData = data.rows
      this.query.total = data.total
      this.loading = false
    },
    async listCar() {
      const { data } = await listCarApi()
      this.carList = data
    }
  },
  mounted() {
    this.pageDriver()
    this.listCar()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-input, .el-select {
    width: 150px;
    margin-right: 15px;
  }
}
</style>
