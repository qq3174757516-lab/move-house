<template>
  <div class='container'>
    <el-table border :data='tableData' height='550'>
      <el-table-column prop='orderNo' label='订单号' align='center' width='120' />
      <el-table-column prop='username' label='用户名' align='center' width='100' />
      <el-table-column prop='driverName' label='司机姓名' align='center' width='100' />
      <el-table-column prop='address' label='地址' align='center' width='150' show-overflow-tooltip />
      <el-table-column prop='price' label='订单金额' align='center' width='100' />
      <el-table-column prop='status' label='状态' align='center'>
        <template #default='scope'>
          <el-tag type='info' v-if='scope.row.status === 0'>未完成</el-tag>
          <el-tag type='primary' v-if='scope.row.status === 1'>已到达</el-tag>
          <el-tag type='success' v-else>已完成</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop='createTime' label='创建时间' align='center' width='150' />
      <el-table-column prop='arriveTime' label='到达时间' align='center' width='150' />
      <el-table-column prop='finishTime' label='完成时间' align='center' width='150' />
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />
  </div>
</template>

<script>
import { pageOrderApi } from '@/api/order'

export default {
  data: () => ({
    tableData: [],
    query: {
      current: 1,
      size: 10,
      total: 0
    }
  }),
  methods: {
    handleCurrentChange(val) {
      this.query.current = val
      this.pageOrder()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pageOrder()
    },
    async pageOrder() {
      const { data } = await pageOrderApi(this.query)
      this.tableData = data.rows
      this.query.total = data.total
    }
  },
  mounted() {
    this.pageOrder()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-input {
    width: 150px;
    margin-right: 15px;
  }
}
</style>
