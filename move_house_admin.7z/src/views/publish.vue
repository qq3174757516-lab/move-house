<template>
  <div class='container'>
    <div class='top'>
      <el-input v-model='query.keyword' placeholder='关键字搜索' clearable />
      <el-button type='primary' @click='pagePublish'>搜索</el-button>
    </div>

    <el-table border :data='tableData' height='500'>
      <el-table-column prop='title' label='标题' align='center' width='100' />
      <el-table-column prop='username' label='发布者' align='center' width='100' />
      <el-table-column prop='content' label='内容' align='center' width='150' show-overflow-tooltip />
      <el-table-column prop='cover' label='封面' align='center' width='150'>
        <template #default='{row}'>
          <el-image :src='$baseUrl + row.cover' :preview-src-list='[$baseUrl + row.cover]' />
        </template>
      </el-table-column>
      <el-table-column prop='imgs' label='详细图片' align='center' width='150'>
        <template #default='scope'>
          <el-image :src='scope.row.imgArr[0]' :preview-src-list='scope.row.imgArr' />
        </template>
      </el-table-column>
      <el-table-column prop='status' label='状态' align='center'>
        <template #default='scope'>
          <el-tag type='info' v-if='scope.row.status === 0'>已发布</el-tag>
          <el-tag v-else-if='scope.row.status === 1'>已估价</el-tag>
          <el-tag type='success' v-else>已完成</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop='address' label='地址' align='center' width='150' show-overflow-tooltip />
      <el-table-column prop='valuation' label='价格' align='center' width='100' />
      <el-table-column prop='createTime' label='发布时间' align='center' width='150' />
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[6, 10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />
  </div>
</template>

<script>
import { pagePublishApi } from '@/api/publish'

export default {
  data: () => ({
    tableData: [],
    query: {
      current: 1,
      size: 6,
      total: 0,
      keyword: ''
    }
  }),
  methods: {
    handleCurrentChange(val) {
      this.query.current = val
      this.pagePublish()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pagePublish()
    },
    async pagePublish() {
      const { data } = await pagePublishApi(this.query)
      data.rows.forEach(item => {
        item.imgArr = item.imgs.split(',').map(img => this.$baseUrl + img)
      })
      this.tableData = data.rows
      this.query.total = data.total
    }
  },
  mounted() {
    this.pagePublish()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-input {
    width: 150px;
    margin-right: 15px;
  }
}
</style>
