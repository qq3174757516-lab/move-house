<template>
  <div>
    <h1>欢迎您: {{ user.username }}</h1>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  computed: {
    ...mapState(['user'])
  },
  mounted() {
    if (!this.user.token) {
      this.$message.warning('登录失效')
      this.$router.push('/login')
    }
  }
}
</script>

<style lang='scss' scoped>

</style>