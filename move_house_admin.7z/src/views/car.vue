<template>
  <div class='container'>
    <div class='top'>
      <el-button type='success' @click='onAdd'>创建车辆</el-button>
      <el-input v-model='query.keyword' placeholder='关键字搜索' clearable @clear='pageCar' />
      <el-button @click='pageCar'>搜索</el-button>
    </div>

    <el-table border :data='tableData' height='500'>
      <el-table-column prop='id' label='编号' align='center' />
      <el-table-column prop='name' label='名称' align='center' />
      <el-table-column prop='carNo' label='车牌号' align='center' />
      <el-table-column prop='repairYear' label='检修年份' align='center' />
      <el-table-column prop='type' label='类型' align='center' />
      <el-table-column prop='status' label='状态' align='center'>
        <template #default='scope'>
          <el-tag type='warning' v-if='scope.row.status === 1'>已分配</el-tag>
          <el-tag v-else type='info'>未分配</el-tag>
        </template>
      </el-table-column>
      <el-table-column fixed='right' label='操作' width='150' align='center'>
        <template #default='scope'>
          <el-popconfirm title='确定删除这条车辆吗' @confirm='onDelete(scope.row.id)'>
            <template #reference>
              <el-button size='mini' type='danger'>删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      style='text-align: center;margin-top: 20px'
      background
      layout='total, sizes, prev, pager, next, jumper'
      :current-page='query.current'
      :page-size='query.size'
      :total='query.total'
      :page-sizes='[6, 10, 15, 30]'
      @size-change='handleSizeChange'
      @current-change='handleCurrentChange'
    />

    <el-dialog center :close-on-click-modal='false' :title='title' :visible.sync='dialogVisible' width='600px'>
      <el-form ref='formRef' :model='form' :rules='rules' label-width='100px'>
        <el-form-item label='名称' prop='name'>
          <el-input placeholder='请填写名称' v-model='form.name' />
        </el-form-item>
        <el-form-item label='车牌号' prop='carNo'>
          <el-input placeholder='请填写车牌号' v-model='form.carNo' />
        </el-form-item>
        <el-form-item label='检修年份' prop='repairYear'>
          <el-input-number v-model='form.repairYear' />
        </el-form-item>
        <el-form-item label='类型' prop='type'>
          <el-select v-model='form.type'>
            <el-option value='小型车' label='小型车' />
            <el-option value='中型车' label='中型车' />
            <el-option value='大型车' label='大型车' />
          </el-select>
        </el-form-item>
      </el-form>
      <span slot='footer' class='dialog-footer'>
        <el-button @click='dialogVisible = false'>取 消</el-button>
        <el-button type='primary' @click='submit'>确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { createCarApi, pageCarApi, deleteCarApi } from '@/api/car'

export default {
  data: () => ({
    tableData: [],
    form: {
      name: '',
      carNo: '',
      repairYear: 2023,
      type: '小型车'
    },
    query: {
      current: 1,
      size: 6,
      total: 0,
      keyword: ''
    },
    rules: {
      name: [{ required: true, message: '名称不能为空', trigger: 'blur' }],
      carNo: [{ required: true, message: '车牌不能为空', trigger: 'blur' }],
      repairYear: [{ required: true, message: '检修年份不能为空', trigger: 'blur' }],
      type: [{ required: true, message: '类型不能为空', trigger: 'blur' }]
    },
    title: '创建车辆',
    dialogVisible: false
  }),
  methods: {
    submit() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        await createCarApi(this.form)
        await this.pageCar()
        this.dialogVisible = false
      })
    },
    async onDelete(id) {
      await deleteCarApi(id)
      await this.pageCar()
    },
    onAdd() {
      this.title = '创建车辆'
      this.form = {
        name: '',
        carNo: '',
        repairYear: 2023,
        type: '小型车'
      }
      this.dialogVisible = true
    },
    handleCurrentChange(val) {
      this.query.current = val
      this.pageCar()
    },
    handleSizeChange(val) {
      this.query.size = val
      this.pageCar()
    },
    async pageCar() {
      const { data } = await pageCarApi(this.query)
      this.tableData = data.rows
      this.query.total = data.total
    }
  },
  mounted() {
    this.pageCar()
  }
}
</script>

<style lang='scss' scoped>
.top {
  margin-bottom: 15px;

  .el-input {
    width: 150px;
    margin: 0 15px;
  }
}
</style>
