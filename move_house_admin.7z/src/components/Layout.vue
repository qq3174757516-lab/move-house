<template>
  <div class='layout'>
    <el-container>
      <el-aside>
        <div class='logo'>
          <i class='el-icon-school'></i>
          <span>搬家管理后台</span>
        </div>
        <el-menu router :default-active='$route.path'>
          <el-menu-item index='/dashboard'>
            <i class='el-icon-menu'></i>
            <span slot='title'>首页</span>
          </el-menu-item>
          <el-menu-item index='/tip'>
            <i class='el-icon-info'></i>
            <span slot='title'>系统公告</span>
          </el-menu-item>
          <el-menu-item index='/car'>
            <i class='el-icon-cpu'></i>
            <span slot='title'>车辆管理</span>
          </el-menu-item>
          <el-menu-item index='/driver'>
            <i class='el-icon-user'></i>
            <span slot='title'>司机列表</span>
          </el-menu-item>
          <el-menu-item index='/complaint'>
            <i class='el-icon-files'></i>
            <span slot='title'>投诉信列表</span>
          </el-menu-item>
          <el-menu-item index='/order'>
            <i class='el-icon-document'></i>
            <span slot='title'>订单列表</span>
          </el-menu-item>
          <el-menu-item index='/publish'>
            <i class='el-icon-receiving'></i>
            <span slot='title'>搬家信息列表</span>
          </el-menu-item>
          <el-menu-item index='/user'>
            <i class='el-icon-user'></i>
            <span slot='title'>用户列表</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <el-header>
          <div class='user'>
            <el-avatar :src='user.avatar' size='medium' />
            <el-dropdown>
              <span class='el-dropdown-link'>
                {{ user.username }}
                <i class='el-icon-arrow-down el-icon--right'></i>
              </span>
              <el-dropdown-menu v-slot='dropdown'>
                <el-dropdown-item><span @click='logout'>退出登录</span></el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </el-header>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
  methods: {
    logout() {
      this.$confirm('确认要退出登陆吗?')
        .then(() => {
          this.setUser({})
          this.$router.push('/login')
        })
        .catch(() => {
        })
    },
    ...mapActions(['setUser'])
  },
  computed: {
    ...mapState(['user'])
  }
}
</script>

<style lang='scss' scoped>
:deep(.el-dialog__body) {
  padding-top: 0;
  padding-bottom: 0;
}

.el-main {
  height: calc(100vh - 50px);
  overflow-y: auto;
}

.el-header {
  height: 50px !important;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #e6e6e6;
  justify-content: flex-end;

  .user {
    display: flex;
    align-items: center;
  }

  span {
    margin-left: 10px;
  }
}

.el-aside {
  display: flex;
  flex-direction: column;
  width: 200px !important;
  height: 100vh;
  overflow-y: auto;

  .el-menu {
    flex: 1;
  }

  .logo {
    display: flex;
    height: 50px;
    align-items: center;
    justify-content: center;
    border-right: 1px solid #e6e6e6;
    border-bottom: 1px solid #e6e6e6;
    cursor: pointer;
    user-select: none;

    i {
      font-size: 35px;
    }

    span {
      font-size: 18px;
      font-weight: 700;
    }
  }
}

.el-dropdown-link {
  cursor: pointer;
  color: #409eff;
}

.el-icon-arrow-down {
  font-size: 12px;
}
</style>
