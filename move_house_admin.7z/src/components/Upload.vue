<template>
  <el-upload
    action=''
    class='avatar-uploader'
    :http-request='httpRequest'
    :show-file-list='false'
    :before-upload='beforeUpload'
  >
    <img v-if='value' :src='$baseUrl + value' class='avatar' alt='' :style='uploadSizeStyle' />
    <i :style='uploadSizeStyle' v-else class='el-icon el-icon-plus'></i>
  </el-upload>
</template>

<script>
import { uploadApi } from '@/api/file'

export default {
  emits: ['update:value', 'success'],
  props: {
    size: {
      type: Number,
      default: 100,
      required: false
    },
    value: {
      type: String,
      default: '',
      required: true
    },
    width: {
      type: String,
      default: '100px',
      required: false
    }
  },
  model: {
    prop: 'value',
    event: 'update:value'
  },
  methods: {
    async httpRequest(options) {
      const file = options.file
      const instance = this.$loading({ text: '正在上传文件...', fullscreen: true })
      try {
        const { data } = await uploadApi(file)
        this.$emit('update:value', data)
        this.$emit('success', data)
      } finally {
        instance.close()
      }
    },
    beforeUpload(file) {
      let suffix = file.name.substring(file.name.lastIndexOf('.') + 1)
      if (!['jpg', 'png', 'jpeg', 'gif'].includes(suffix)) {
        this.$message.error('只能上传图片!')
        return false
      }

      if (file.size > this.size * 1024 * 1024) {
        this.$message.error(`文件大小不能超过 ${this.size} MB!`)
        return false
      }

      return true
    }
  },
  computed: {
    uploadSizeStyle() {
      return {
        width: this.width,
        height: this.width
      }
    }
  }
}
</script>

<style scoped lang='scss'>
.avatar {
  display: block;
}

:deep(.el-upload) {
  border: 1px dashed lightgray;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: all 0.2s ease-in-out;
}

:deep(.el-upload):hover {
  border-color: #409eff;
}

.el-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  color: #8c939d;
  text-align: center;
}
</style>
