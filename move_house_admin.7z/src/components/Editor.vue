<template>
  <div class='editor-box'>
    <Toolbar
      style='border-bottom: 1px solid #ccc'
      :editor='editor'
      :defaultConfig='toolbarConfig'
    />
    <Editor
      style='height: 300px; overflow-y: hidden;'
      v-model='content'
      :defaultConfig='editorConfig'
      @onCreated='onCreate'
    />
  </div>
</template>

<script>
import '@wangeditor/editor/dist/css/style.css' // 引入 css
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import { uploadApi } from '@/api/file'

export default {
  components: { Editor, Toolbar },
  emits: ['update:value'],
  props: {
    value: String
  },
  model: {
    prop: 'value',
    event: 'update:value'
  },
  data() {
    return {
      editor: null,
      toolbarConfig: {},
      editorConfig: {
        MENU_CONF: {
          uploadImage: {
            allowedFileTypes: ['image/*'],
            // 自定义上传
            customUpload: this.upload
          }
        }
      }
    }
  },
  methods: {
    onCreate(editor) {
      this.editor = editor
    },
    async upload(file, insertFn) {
      // file 即选中的文件
      const { data } = await uploadApi(file)
      // 自己实现上传，并得到图片 url alt href
      // 最后插入图片
      insertFn(this.$baseUrl + data, '', '')
    }
  },
  computed: {
    content: {
      set(value) {
        this.$emit('update:value', value)
      },
      get() {
        return this.value
      }
    }
  },
  mounted() {

  },
  destroyed() {
    if (this.editor == null) return
    this.editor.destroy()
  }
}
</script>

<style scoped lang='scss'>
.editor-box {
  border: 1px solid #ccc;
  z-index: 2;
}
</style>