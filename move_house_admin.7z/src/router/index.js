import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/dashboard',
    component: () => import('@/components/Layout.vue'),
    children: [{
      path: '/dashboard',
      component: () => import('@/views/dashboard.vue')
    }, {
      path: '/tip',
      component: () => import('@/views/tip.vue')
    }, {
      path: '/car',
      component: () => import('@/views/car.vue')
    }, {
      path: '/driver',
      component: () => import('@/views/driver.vue')
    }, {
      path: '/complaint',
      component: () => import('@/views/complaint.vue')
    }, {
      path: '/order',
      component: () => import('@/views/order.vue')
    }, {
      path: '/publish',
      component: () => import('@/views/publish.vue')
    }, {
      path: '/user',
      component: () => import('@/views/user.vue')
    }]
  }, {
    path: '/login',
    component: () => import('@/views/login.vue')
  }
]

const router = new VueRouter({
  routes,
  mode: 'history'
})

export default router
