import request from '@/util/request'

export function pagePublishApi(params) {
  return request({
    url: '/publish/page',
    method: 'get',
    params
  })
}