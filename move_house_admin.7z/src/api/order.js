import request from '@/util/request'

export function pageOrderApi(params) {
  return request({
    url: '/order/page',
    method: 'get',
    params
  })
}