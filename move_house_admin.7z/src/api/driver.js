import request from '@/util/request'

export function acceptDriverApi(id, carId) {
  return request({
    url: `/driver/accept/${id}/${carId}`,
    method: 'patch'
  })
}

export function dismissDriverApi(id) {
  return request({
    url: `/driver/dismiss/${id}`,
    method: 'patch'
  })
}

export function deleteDriverApi(id) {
  return request({
    url: `/driver/${id}`,
    method: 'delete'
  })
}

export function pageDriverApi(params) {
  return request({
    url: '/driver/page',
    method: 'get',
    params
  })
}

export function listDriverApi() {
  return request({
    url: '/driver',
    method: 'get',
  })
}