import request from '@/util/request'

export function createCarApi(data) {
  return request({
    url: '/car',
    method: 'post',
    data
  })
}

export function deleteCarApi(id) {
  return request({
    url: '/car/' + id,
    method: 'delete'
  })
}

export function pageCarApi(params) {
  return request({
    url: '/car/page',
    method: 'get',
    params
  })
}

export function listCarApi() {
  return request({
    url: '/car',
    method: 'get',
  })
}