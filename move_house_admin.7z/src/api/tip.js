import request from '@/util/request'

export function createTipApi(data) {
  return request({
    url: '/tip',
    method: 'post',
    data
  })
}

export function deleteTipApi(id) {
  return request({
    url: '/tip/' + id,
    method: 'delete'
  })
}

export function updateTipApi(data) {
  return request({
    url: '/tip',
    method: 'put',
    data
  })
}

export function listTipApi() {
  return request({
    url: '/tip',
    method: 'get'
  })
}