import request from '@/util/request'

export function loginAdminApi(data) {
  return request({
    url: '/admin/login',
    method: 'post',
    data
  })
}