import request from '@/util/request'

export function loginUserApi(data) {
  return request({
    url: '/student/login',
    method: 'post',
    data
  })
}

export function registerUserApi(data) {
  return request({
    url: '/student/register',
    method: 'post',
    data
  })
}

export function updateStudentApi(data) {
  return request({
    url: '/student',
    method: 'put',
    data
  })
}

export function infoStudentApi() {
  return request({
    url: '/student/info',
    method: 'get'
  })
}

export function pageUserApi(params) {
  return request({
    url: '/user/page',
    method: 'get',
    params
  })
}