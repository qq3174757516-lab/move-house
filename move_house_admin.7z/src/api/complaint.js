import request from '@/util/request'

export function pageComplaintApi(params) {
  return request({
    url: '/complaint/page',
    method: 'get',
    params
  })
}