import axios from 'axios'
import { Notification } from 'element-ui'
import router from '@/router'
import Vue from 'vue'
import store from '@/store'

const service = axios.create({
  // 默认地址
  baseURL: Vue.prototype.$baseUrl,
  // 设置超时时间
  timeout: 120000,
  // 跨域时候允许携带凭证
  withCredentials: true
})

service.interceptors.request.use(config => {
  const user = store.state.user
  config.headers['token'] = user.token
  return config
})

service.interceptors.response.use(res => {
  let data = res.data
  let code = data.code
  let method = res.config.method

  if (code === 401) {
    Notification({
      type: 'warning',
      title: '温馨提示!',
      message: '请先登录!'
    })
    router.push('/login')
    return Promise.reject(data)
  }

  if (code !== 200) {
    Notification({
      type: 'warning',
      title: '温馨提示!',
      message: data.message
    })
    return Promise.reject(data)
  }

  if (method !== 'get') {
    Notification({
      type: 'success',
      title: '温馨提示',
      message: '操作成功'
    })
  }

  return Promise.resolve(data)
})

export default service